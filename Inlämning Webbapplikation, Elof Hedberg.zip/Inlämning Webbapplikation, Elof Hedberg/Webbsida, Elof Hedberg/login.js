
var Email = document.getElementById('Email');
var pw = document.getElementById('pw');



function store() {
    localStorage.setItem('Email', Email.value);
    localStorage.setItem('pw', pw.value);
}


function check() {


    var storedName = localStorage.getItem('Email');
    var storedPw = localStorage.getItem('pw');


    var userName = document.getElementById('userName');
    var userPw = document.getElementById('userPw');



    if(userName.value == storedName && userPw.value == storedPw) {
        alert('Du är inloggad!');
    }else {
        alert('Något gick fel!');
    }
}